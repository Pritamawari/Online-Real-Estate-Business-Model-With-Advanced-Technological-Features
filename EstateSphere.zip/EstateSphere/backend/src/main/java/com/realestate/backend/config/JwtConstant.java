package com.realestate.backend.config;

public class JwtConstant {
    public static  final String SECRET_KEY="kksksskskksknedneieeiefiohihfeifioeeefoieifieifei";
    public static final String JWT_HEADER="Authorization";
}
